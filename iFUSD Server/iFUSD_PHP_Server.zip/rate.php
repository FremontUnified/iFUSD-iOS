<?
//This redirect users to our app page on the app store.
header('Location:itms-apps://ax.itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?type=Purple+Software&id=355313284');
?>