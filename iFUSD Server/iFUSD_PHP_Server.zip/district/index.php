<? include('header.php'); ?>
<body>

<div data-role="page" > 
 <!--
	<div data-role="header"  data-theme="b"> 
				<h1>Fremont Unified </h1> 
	
	</div><!-- /header --> 
 
	<div data-role="content" data-theme="b">	
	 <ul data-role="listview" class=" ui-listview" data-theme="b">
						
						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="page.php?url=http://www.fremont.k12.ca.us/domain/6" class="ui-link-inherit"><h2 class="ui-li-heading">Office of the Superintendent</h2><p class="ui-li-desc">Updates from the Superintendent</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>
						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="home.php?url=www.fmtusd.org/site/default.aspx?PageID/domain/6" class="ui-link-inherit"><h2 class="ui-li-heading">Frontpage Updates</h2><p class="ui-li-desc">Updates from the district</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>

						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="page.php?url=http://www.fremont.k12.ca.us/domain/2" class="ui-link-inherit"> <h2 class="ui-li-heading">About FUSD</h2><p class="ui-li-desc">Learn more about FUSD</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>

						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="page.php?url=http://www.fremont.k12.ca.us/domain/8" class="ui-link-inherit"><h2 class="ui-li-heading">Contact FUSD</h2><p class="ui-li-desc">Call, Email,or Visit FUSD </p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>


						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="page.php?url=http://www.fremont.k12.ca.us/page/9" class="ui-link-inherit"><h2 class="ui-li-heading">Giving to the District</h2><p class="ui-li-desc">Donate to FUSD</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>

						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="page.php?url=http://www.fremont.k12.ca.us/domain/44" class="ui-link-inherit"><h2 class="ui-li-heading">District Committees</h2><p class="ui-li-desc">List of District Committees</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>


</Ul></div><!-- /content --> 

<? include('footer.php'); ?>
