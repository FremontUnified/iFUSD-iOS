<!DOCTYPE HTML>
<html> 
   <head> 
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

   <title>Fremont Unified - Sumukh Sridhara</title> 

<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.css" />
<link rel="stylesheet" href="http://ifusd.fremontunified.com/fusdweb/universal.css">

<script src="http://code.jquery.com/jquery-1.5.2.min.js"></script>
<script src="http://ifusd.fremontunified.com/fusdweb/universal.js"></script>
<script src="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.js"></script>
</head> 

