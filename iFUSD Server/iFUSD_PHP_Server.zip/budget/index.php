<? include('header.php'); ?>
<body>

<div data-role="page" > 
 <!--
	<div data-role="header"  data-theme="b"> 
				<h1>Fremont Unified </h1> 
	
	</div><!-- /header --> 
 
	<div data-role="content" data-theme="b">	
	 <ul data-role="listview" class=" ui-listview" data-theme="b">
						
						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/78/BF21_2012_13AdoptedBudge.pdf" rel="external" class="ui-link-inherit">
						<h2 class="ui-li-heading">FUSD Budget</h2><p class="ui-li-desc">Recent Updates and Info</p>
						<span class="ui-icon ui-icon-arrow-r"></span></a></div></li>
						
						

						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="page.php?url=http://www.fremont.k12.ca.us//Domain/78"  rel="external" class="ui-link-inherit"><h2 class="ui-li-heading">Business Services</h2><p class="ui-li-desc">Financial Information</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>


</ul></div><!-- /content --> 
	<div data-role="footer" data-theme="b" align=center data-position="fixed">	
iFUSD
</div><!-- /footer --> 






</div>

</body>
</html>