<!DOCTYPE HTML>
<html> 
   <head> 
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

   <title>Fremont Unified - Sumukh Sridhara</title> 
	<meta name="viewport" content="width=device-width, initial-scale=1 user-scaleable=no">
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0b1/jquery.mobile-1.0b1.min.css">
	<script src="http://code.jquery.com/jquery-1.6.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.0b1/jquery.mobile-1.0b1.min.js"></script>
	
</head>
<body>

<div data-role="page" > 
 
	<div data-role="header"  data-theme="b"> 
								<a href="index.php" class="ui-btn-left" data-icon="back"  data-theme="e"
           data-direction="reverse">Back</a><h1>SARC </h1> 
	
	</div><!-- /header --> 
 
	<div data-role="content" data-theme="b">	

 <?php
//  Advanced cURL Scrape
//  Obtain data from url and force links to work
//  This code was written by Michael Devaney
//  Note: You might want to cache this
//  All I ask is that you do not remove these notes
//  Thank you
$url = $_GET["url"];
$ch = curl_init ($url); //URL to Scrape
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$page = curl_exec($ch);

preg_match('#<p class="docSubhead"[^>]*>(.+?)<p class="copyright">#is', $page, $matches, $links); // grabs anything between <p> </p> tags
foreach ($matches as &$match) {
    $match = str_replace('href="', 'href="http://www.fremont.schoolwisepress.com', $match); 
	//This is used to make sure links work.
}
// output html, styles, and more.
echo 'Do a 2 finger swipe (left) to navigate back at any time! <br><br>';
echo $matches[1]; // change [1] to [2] If you want to grab data between the second <p></p> tags  
echo '</div>';
?>
 	<div data-role="footer" data-theme="b" align=center data-position="static">	
	<a href="javascript: history.go(-1)"> Fremont Unified </a>  <a href="about.php" data-transition="slideup">About</a>
</div><!-- /footer --> 






</div>

</body>
</html>