<?php
$url = 'http://www.fmtusd.org/Page/16';
echo $add;
$ch = curl_init ($url); //URL to Scrape
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$page = curl_exec($ch);

preg_match('#<div class="SWContentBODY" style="position: relative;"[^>]*>(.+?)<div class="ui-widget-footer">#is', $page, $matches, $links); // grabs anything between <p> </p> tags
foreach ($matches as &$match) {
    $match = str_replace('href="http://fremont.schoolwise', 'href="sarc.php?url=http://fremont.schoolwise', $match); 
	//This is used to make sure links work.
}
// output html, styles, and more.
echo $matches[1]; // change [1] to [2] If you want to grab data between the second <p></p> tags  
?>

