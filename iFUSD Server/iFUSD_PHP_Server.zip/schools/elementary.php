<? include('header.php'); ?>
<body class="ui-mobile-viewport">

<div data-role="page" id="page" class="ui-page ui-body-c ui-page-active" "> 
				<div data-role="header"  data-theme="b"> 
				<a href="index.php" class="ui-btn-left" data-theme="e" data-icon='arrow-l'  
           data-direction="reverse">Back</a><h1>Elementary </h1> 
	
	</div><!-- /header --> 

	<div data-role="content" class="ui-content" role="main">
	 

<div class="content-primary">	

	<ul data-role="listview" data-filter="fasle" data-filter-placeholder="Search schools..." data-filter-theme="d" class="ui-listview">
				
				
				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-down-undefined ui-btn-up-undefined">A</li>
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c">
			<a href="detail/elementary/index.php?school=ard" rel="external" class="ui-link-inherit">

					<div class="ui-btn-inner ui-li">
							<div class="ui-btn-text">
								Ardenwood Elementary
									</div>
										<span class="ui-icon ui-icon-arrow-r"></span></a>
											</div>
												</li>
												
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=aze" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Azevada Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>

				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">B</li>
				
				
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=bla" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Blacow Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=bri" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Brier Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=bro" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Brookvale  Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">C</li>
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=cab" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Cabrillo Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=cha" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Chadbourne Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">D</li>
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=dur" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Durham Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">F</li>
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=for" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Forest Park Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">G</li>
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=gle" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Glenmoor Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=gom" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Gomes Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=gre" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Green Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=gri" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Grimmer Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				

				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">H</li>
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=hir" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Hirsch Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">L</li>
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=lei" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Leitch Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				

				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">M</li>
				
				
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=mal" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Maloney Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=mat" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Mattos Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=mil" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Millard  Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>									
				
				
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=msj" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Mission San Jose Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>									
					
					
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=mve" rel="external" target="_blank" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Mission Valley Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				


				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">N</li>
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=nil" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Niles Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">O</li>
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=oli" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Oliveira Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">P</li>

				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=par" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Parkmont Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=pat" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Patterson Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				

				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">V</li>
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=val" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Vallejo Mill Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				

		<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">W</li>
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=wrm" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Warm Springs Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=war" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Warwick Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><a href="detail/elementary/index.php?school=wei" rel="external" class="ui-link-inherit">
				<div class="ui-btn-inner ui-li"><div class="ui-btn-text">Weibel Elementary</div><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>				

			</ul>
			</div>			
				<div data-role="footer" data-theme="b" align="center" data-position="fixed" class="ui-bar-b ui-footer ui-footer-fixed ui-fixed-inline fade" role="contentinfo">	




</div>


</div>


</div><div class="ui-loader ui-body-a ui-corner-all" style="top: 213.5px; "><span class="ui-icon ui-icon-loading spin"></span><h1>loading</h1></div></body>				<div data-role="footer" data-theme="b" align=center data-position="static">	
	<a href="javascript: history.go(-1)"> Fremont Unified </a>  <a href="about.php" data-transition="slideup">About</a>
</div><!-- /footer --> 






</div>

</body>
</html>