<!DOCTYPE HTML>
<html> 
   <head> 
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

   <title>Fremont Unified</title> 
<meta name="viewport" content = "width = device-width, user-scalable = no" />  
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0b1/jquery.mobile-1.0b1.min.css">
	<script src="http://code.jquery.com/jquery-1.6.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.0b1/jquery.mobile-1.0b1.min.js"></script>
	<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-24659969-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>

<body>

<div id="page" data-role="page" >
 <!--
	<div data-role="header"  data-theme="b"> 
				<h1>Fremont Unified </h1> 
	
	</div><!-- /header --> 
 
	<div data-role="content" data-theme="b">	
	 <ul data-role="listview" class="ui-listview" data-theme="b">
						
	<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="elementary.php" rel="external" class="ui-link-inherit"><h2 class="ui-li-heading">Elementary Schools</h2><p class="ui-li-desc">K-6 Schools</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>
						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="junior.php" class="ui-link-inherit"> <h2 class="ui-li-heading">Junior High Schools</h2><p class="ui-li-desc">7th and 8th Grade</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>
						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="high.php" class="ui-link-inherit"><h2 class="ui-li-heading">High Schools</h2><p class="ui-li-desc">9th-12th grade</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>

						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="other.php" class="ui-link-inherit"><h2 class="ui-li-heading">More Schools</h2><p class="ui-li-desc">Alternative Programs </p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>
						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a  rel=external href="sarc/" class="ui-link-inherit"><h2 class="ui-li-heading">School Accountability </h2><p class="ui-li-desc"> API scores (SARC)</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>

</ul></div><!-- /content --> 
<? include('footer.php'); ?>
</body> </html>
