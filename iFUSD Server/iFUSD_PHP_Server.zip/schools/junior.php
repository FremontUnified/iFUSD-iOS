<? include('header.php'); ?>
<body class="ui-mobile-viewport">

<div data-role="page" id="page" class="ui-page ui-body-c ui-page-active" "> 
				<div data-role="header"  data-theme="b"> 
				<a href="index.php" class="ui-btn-left"  data-theme="e" data-icon='arrow-l'  
  
           data-direction="reverse">Back</a><h1>Junior High </h1> 
	
	</div><!-- /header --> 

	<div data-role="content" class="ui-content" role="main">
	 

<div class="content-primary">	

	<ul data-role="listview" data-filter="true" data-filter-placeholder="Search schools..." data-filter-theme="d" class="ui-listview">
				
				
				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-down-undefined ui-btn-up-undefined">C</li>
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><div class="ui-btn-inner ui-li"><div class="ui-btn-text"><a href="detail/cjh/" rel="external" class="ui-link-inherit">Centerville Junior High</a></div><span class="ui-icon ui-icon-arrow-r"></span></div></li>

				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">B</li>


				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><div class="ui-btn-inner ui-li"><div class="ui-btn-text"><a href="detail/hopkins/" rel="external" class="ui-link-inherit">Hopkins Junior High</a></div><span class="ui-icon ui-icon-arrow-r"></span></div></li>
								<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><div class="ui-btn-inner ui-li"><div class="ui-btn-text"><a href="detail/horner/" rel="external" class="ui-link-inherit">Horner Junior High</a></div><span class="ui-icon ui-icon-arrow-r"></span></div></li>

				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">T</li>
				
				
				
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><div class="ui-btn-inner ui-li"><div class="ui-btn-text"><a href="detail/thornton/" rel="external" class="ui-link-inherit">Thornton Junior High</a></div><span class="ui-icon ui-icon-arrow-r"></span></div></li>
				
				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">W</li>
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><div class="ui-btn-inner ui-li"><div class="ui-btn-text"><a href="detail/walters/" rel="external"  class="ui-link-inherit">Walters Junior High</a></div><span class="ui-icon ui-icon-arrow-r"></span></div></li>
			</ul>
			</div>			
				<div data-role="footer" data-theme="b" align="center" data-position="fixed" class="ui-bar-b ui-footer ui-footer-fixed ui-fixed-inline fade" role="contentinfo">	



</div>



</div>


</div><div class="ui-loader ui-body-a ui-corner-all" style="top: 213.5px; "><span class="ui-icon ui-icon-loading spin"></span><h1>loading</h1></div></body>				<div data-role="footer" data-theme="b" align=center data-position="static">	
	<a href="javascript: history.go(-1)"> Fremont Unified </a>  <a href="about.php" data-transition="slideup">About</a>
</div><!-- /footer --> 






</div>

</body>
</html>