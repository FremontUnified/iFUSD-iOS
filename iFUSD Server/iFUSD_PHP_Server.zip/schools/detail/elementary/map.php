<?
$geo = $_GET['geo'];
?>
<!DOCTYPE HTML> 
<html lang="en-US"> 
<head> 
 <title>FUSD</title>
    
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0b1/jquery.mobile-1.0b1.min.css">
<meta name="viewport" content="initial-scale=1.0" />

	<script src="http://code.jquery.com/jquery-1.6.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.0b1/jquery.mobile-1.0b1.min.js"></script>
	 <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
	
	
	
</head> 
<body> 
 
	<div data-role="page" class="page-map"> 
		<script type="text/javascript" > $('.page-map').live("pagecreate", function() {
		
    var school = new google.maps.LatLng<? echo $geo ; ?> ;

	var latlng = new google.maps.LatLng<? echo $geo ; ?> ;	
	var myOptions = {
		zoom: 18,
		center: latlng,
		       zoomControl: true,
              zoomControlOptions: {
        style: google.maps.ZoomControlStyle.LARGE
        },


		mapTypeId: google.maps.MapTypeId.HYBRID
	
    };
    var map = new google.maps.Map(document.getElementById("map-canvas"),myOptions);
      marker = new google.maps.Marker({
    map:map,
    draggable:false,
    animation: google.maps.Animation.DROP,

    position: school
  });

});</script> 
		<link rel="stylesheet" href="map.css" /> 
		
		<div data-role="header" data-theme="b"><a rel="external" href='javascript:history.go(-1)' class='ui-btn-left ui-btn-back' data-icon='arrow-l'>Back</a>
<h1>School Location</h1></div> 
		<div data-role="content"> 
			<div id="map-canvas"> 
				<!-- map loads here... --> 
			</div> 
		</div> 
	</div> 
	
</body> 
</html> 