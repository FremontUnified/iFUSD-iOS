<? 
$school = $_GET['school'];
if ($school === "ard") {
$schoolname = "Ardenwood Elementary"; 
$abbr = "Ardenwood"; 
$addr = "33955 Emilia Lane"; 
$addr2 = "Fremont, CA 94555"; 
$tel= "5107940392";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/ardenwoodsign.jpg";
$pr= "Paula Rugg";
$ar= "Pam Fallon";
$geo= "(37.572658, -122.053012)";  
}


if ($school == "aze") {
$schoolname = "Azevada Elementary"; 
$abbr = "Azevada"; 
$addr = "39450 Royal Palm Drive"; 
$addr2 = "Fremont, CA 94538"; 
$tel="15106573900";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/Azevada.jpg";
$pr= "Carole Diamond";
$ar= "Becky Galloway";
$geo= "(37.530914,-121.994142)";  }

if ($school == "bla") {
$schoolname= "Blacow Elementary"; 
$abbr = "Blacow"; 
$addr = "40404 Sundale Drive"; 
$addr2 = "Fremont, CA 94538"; 
$tel="15106565121";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/blacowsignbobcatfp.jpg";
$pr= "Angela Morariu";
$ar= "Lisa James";
$geo= "(37.528107,-121.975941)";  }


if ($school == "bri") {
$schoolname = "Brier Elementary"; 
$abbr = "Brier"; 
$addr = "39201 Sundale Drive"; 
$addr2 = "Fremont, CA 94538"; 
$tel= "15106575023";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/Brier_Bronco.jpg";
$pr= "Jan March";
$ar= "Denise Berger";
$geo= "(37.540394,-121.98416)";  }


if ($school == "bro") {
$schoolname = "Brookvale Elementary"; 
$abbr = "Brookvale"; 
$addr = "3400 Nicolet Avenue"; 
$addr2 = "Fremont, CA 94536"; 
$tel="15107975940";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/brookvalelogo.jpg";
$pr= "Cindy Hicks";
$ar= "Lena Anderson";
$geo= "(37.568978,-122.014698)";  }



if ($school == "cab") {
$schoolname = "Cabrillo Elementary"; 
$abbr = "Cabrillo"; 
$addr = "36700 San Pedro Drive"; 
$addr2 = "Fremont, CA 94536"; 
$tel="15107923232";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/cabrillo.jpg";
$pr= "Giselle Hudson";
$ar= "Terri Yan";
$geo= "(37.550985,-122.023791)";  }


if ($school == "cha") {
$schoolname = "Chadbourne Elementary"; 
$abbr = "Chadbourne"; 
$addr = "801 Plymouth Avenue"; 
$addr2 = "Fremont, CA 94539"; 
$tel="656-5242";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/Chadbourne_Logo-web.jpg";
$pr= "Tess Melendez";
$ar= "Bobbie Platt";
$geo="(37.542123,-121.939865)";  }


if ($school == "dur") {
$schoolname = "Durham Elementary"; 
$abbr = "Durham"; 
$addr = "40292 Leslie Street"; 
$addr2 = "Fremont, CA 94538"; 
$tel= "15106577080";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/DurhamEagle.jpg";
$pr= "Teresa Bonaccorsi";
$ar= "Patty Sandoval";
$geo= "(37.541827,-121.96628)";  }


if ($school == "for") {
$schoolname = "Forest Park Elementary"; 
$abbr = "Forest Park "; 
$addr = "34400 Maybird Circle"; 
$addr2 = "Fremont, CA 94555"; 
$tel= "15107130141";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/directory_fp.jpg";
$pr= "Guillermo Gomez";
$ar= "Karin Hasson";
$geo= "(37.561161,-122.051776)";  }


if ($school == "gla") {
$schoolname = "Glankler Preschool"; 
$abbr = "Glankler"; 
$addr = "39207 Sundale Drive"; 
$addr2 = "Fremont, CA 94538"; 
$tel= "15106511190";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/glankler_symbol.gif";
$pr= "Anita Allardice";
$ar= "Roni Gean";
$geo= "(37.540113,-121.9843880";}




if ($school == "gle") {
$schoolname = "Glenmoor Elementary"; 
$abbr = "Glenmoor"; 
$addr = "4620 Mattos Drive"; 
$addr2 = "Fremont, CA 94536"; 
$tel= "15107970740";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/Elem_Pics/Glenmoor.jpg";
$pr= "Vivian Martin";
$ar= "Linda Sayers";
$geo= "(37.545739,-122.004907)";  }



if ($school == "gom") {
$schoolname = "Gomes Elementary"; 
$abbr = "Gomes"; 
$addr = "555 Lemos Lane"; 
$addr2 = "Fremont, CA 94539"; 
$tel= "15106563414";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/gomes.jpg";
$pr= "Doug Whipple";
$ar= "Klara Deigner";
$geo= "(37.550102,-121.947915)";  }



if ($school == "gre") {
$schoolname = "Green Elementary"; 
$abbr = "Green"; 
$addr = "42875 Gatewood Street"; 
$addr2 = "Fremont, CA 94538"; 
$tel="15106566438";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/FightingHornet-flash.jpg";
$pr= "Kimberly Kelly, Interim";
$ar= "Jennifer Wong";
$geo= "(37.518866,-121.961181)";  }



if ($school == "gri") {
$schoolname = "Grimmer Elementary"; 
$abbr = "Grimmer"; 
$addr = "43030 Newport Drive"; 
$addr2 = "Fremont, CA 94538"; 
$tel= "15106561250";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/GrimmerSign.jpg";
$pr= "Judy Nye (Interim)";  
$ar= "Anita McDonald";
$geo= "(37.520332,-121.950497)";  }



if ($school == "hir") {
$schoolname = "Hirsch Elementary"; 
$abbr = "Hirsch"; 
$addr = "41399 Chapel Way"; 
$addr2 = "Fremont, CA 94538"; 
$tel= "15106573537";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/HirschLogo.JPG";
$pr= "Jennifer Casey";
$ar= "Julie Asher";
$geo= "(37.528245,-121.962848)";  }




if ($school == "lei") {
$schoolname = "Leitch Elementary"; 
$abbr = "Leitch"; 
$addr = "47100 Fernald Street"; 
$addr2 = "Fremont, CA 94539"; 
$tel= "15106576100";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/Leitch_web.jpg";
$pr= "Mary Liu-Lee";
$ar= "Kiki Heller";
$geo= "(37.486954,-121.923434)";  }



if ($school === "mal") {
$schoolname = "Maloney Elementary"; 
$abbr = "Maloney"; 
$addr = "38700 Logan Drive"; 
$addr2 = "Fremont, CA 94536"; 
$tel= "15107974426";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/maloney.jpg";
$pr= "Sumi Okuda";
$ar= "Angie Andersen";
$geo= "(37.546429,-121.997575)";  }



if ($school == "mat") {
$schoolname = "Mattos Elementary"; 
$abbr = "Mattos"; 
$addr = "37944 Farwell Drive"; 
$addr2 = "Fremont, CA 94536"; 
$tel= "15107931359";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/mattos_school.jpg";
$pr= "Tammy Eglinton";
$ar= "Georgia Graham";
$geo= "(37.538405,-122.012576)";  }



if ($school == "mil") {
$schoolname = "Millard Elementary"; 
$abbr = "Millard"; 
$addr = "5200 Valpey Park Drive"; 
$addr2 = "Fremont, CA 94538"; 
$tel= "15106570344";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/millardmustang.jpg";
$pr= "Karen Robertson";
$ar= "Virginia Holmes";
$geo= "(37.520066,-121.974259)";  }



if ($school == "msj") {
$schoolname = "Mission San Jose Elementary"; 
$abbr = "MSJE"; 
$addr = "43545 Bryant Street"; 
$addr2 = "Fremont, CA 94539"; 
$tel= "15106561200";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/msje_sign.jpg";
$pr= "Chuck Graves";
$ar= "Shanthika Sukumar";
$geo= "(37.528154,-121.921805)";  }




if ($school == "mve") {
$schoolname = "Mission Valley Elementary"; 
$abbr = "Mission Valley"; 
$addr = "41700 Denise Street"; 
$addr2 = "Fremont, CA 94539"; 
$tel= "15106562000";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/MVmarquee.gif";
$pr= "Cary Bossi";
$ar= "Jennifer Graves";
$geo= "(37.53652,-121.946225)";  }



if ($school == "nil") {
$schoolname = "Niles Elementary"; 
$abbr = "Niles"; 
$addr = "37141 Second Street"; 
$addr2 = "Fremont, CA 94536"; 
$tel= "15107931141";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/niles2.jpg";
$pr= "Jim Hough";
$ar= "Michele Morhous";
$geo= "(37.576086,-121.984788)";  }



if ($school == "oli") {
$schoolname = "Oliveira Elementary"; 
$abbr = "Oliveira"; 
$addr = "4180 Alder Avenue"; 
$addr2 = "Fremont, CA 94536"; 
$tel= "15107971135";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/OLiveira.jpg";
$pr= "Linda Anderson";
$ar= "Kathy Kimberlin";
$geo= "(37.560552,-122.017639)";  }



if ($school == "par") {
$schoolname = "Parkmont Elementary"; 
$abbr = "Parkmont"; 
$addr = "2601 Parkside Drive"; 
$addr2 = "Fremont, CA 94536"; 
$tel= "15107937492";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/parkmont.gif";
$pr= "Marianne Schmidt";
$ar= "Marcie Lemos";
$geo= "(37.560054,-121.985243)";  }



if ($school == "pat") {
$schoolname = "Patterson Elementary"; 
$abbr = "Patterson"; 
$addr = "35521 Cabrillo Drive"; 
$addr2 = "Fremont, CA 94536"; 
$tel= "15107930420";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/PattersonLogoPanthers.jpg";
$pr= "Marlene Davis";
$ar= "Chris Lavey";
$geo= "(37.562323,-122.030893)";  }



if ($school == "val") {
$schoolname = "Vallejo Mill Elementary"; 
$abbr = "Vallejo"; 
$addr = "38569 Canyon Heights Dr."; 
$addr2 = "Fremont, CA 94536"; 
$tel= "15107931441";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/vallejomill.jpg";
$pr= "Mary Lou Ulloa";
$ar= "Marilyn Mascsak";
$geo= "37.574501,-121.961815";  }


if ($school == "wrm") {
$schoolname = "Warm Springs Elementary"; 
$abbr = "Warm Springs"; 
$addr = "47370 Warm Springs Bl."; 
$addr2 = "Fremont,CA"; 
$tel= "15106561611";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/WarmSpringsBldg.jpg";
$pr= "Brett Nelson";
$ar= "Kathy Forrest";
$geo= "(37.482586,-121.925129)";  }



if ($school == "war") {
$schoolname = "Warwick Elementary"; 
$abbr = "Warwick"; 
$addr = "3375 Warwick Road"; 
$addr2 = "Fremont, CA 94555"; 
$tel= "15107938660";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/Warwick_001.jpg";
$pr= "Vivienne Paratore";
$ar= "Jane Dymond";
$geo= "(37.577319,-122.031855)";  }  

 if ($school == "wei") {
$schoolname = "Weibel Elementary"; 
$abbr = "Weibel"; 
$addr = "45135 So. Grimmer Blvd."; 
$addr2 = "Fremont, CA 94539"; 
$tel="15106516958";
$img= "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/Weibel-Sign_0032.jpg";
$pr= "Genevieve Randolph";
$ar= "Dora Vasquez";
$geo= "(37.507103,-121.927323)";  }


?>
<!DOCTYPE HTML>
<html>
  <head>
    <meta name="viewport" content="width=320px; user-scalable=yes" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
<meta names="apple-mobile-web-app-status-bar-style" content="black-translucent" />

    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <title>FUSD</title>
    
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0b1/jquery.mobile-1.0b1.min.css">
	    <link rel="stylesheet" href="mapapp.css" type="text/css">

	<script src="http://code.jquery.com/jquery-1.6.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.0b1/jquery.mobile-1.0b1.min.js"></script>
	 <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
	 	<script type="text/javascript" src="ui/jquery.ui.map.min.js"></script>
	<script src="http://maps.google.com/maps/api/js?sensor=true"></script> 

<script type="text/javascript">

/**
 * 
 * NoClickDelay
 * http://cubiq.org/
 * 
 */
function NoClickDelay(el) {
	this.element = el;
	if( window.Touch ) this.element.addEventListener('touchstart', this, false);
}

NoClickDelay.prototype = {
	handleEvent: function(e) {
		switch(e.type) {
			case 'touchstart': this.onTouchStart(e); break;
			case 'touchmove': this.onTouchMove(e); break;
			case 'touchend': this.onTouchEnd(e); break;
		}
	},
	
	onTouchStart: function(e) {
		e.preventDefault();
		this.moved = false;
		
		this.element.addEventListener('touchmove', this, false);
		this.element.addEventListener('touchend', this, false);
	},
	
	onTouchMove: function(e) {
		this.moved = true;
	},
	
	onTouchEnd: function(e) {
		this.element.removeEventListener('touchmove', this, false);
		this.element.removeEventListener('touchend', this, false);

		if( !this.moved ) {
			var theTarget = document.elementFromPoint(e.changedTouches[0].clientX, e.changedTouches[0].clientY);
			if(theTarget.nodeType == 3) theTarget = theTarget.parentNode;

			var theEvent = document.createEvent('MouseEvents');
			theEvent.initEvent('click', true, true);
			theTarget.dispatchEvent(theEvent);
		}
	}
};

function loaded() {
}

window.addEventListener('load', function(){ setTimeout(function(){ loaded(); }, 100) }, true);
	new NoClickDelay(page);

</script>


	</head>
  <body>
	<div data-role="page" id="page" data-theme="b" id="page-home">
<!--	<div data-role="header" data-theme="b">
	<h1>
School
	</h1>
	</div> -->
	<div data-role="content" id="contenthome">

				<ul data-role="listview" data-theme="c" data-dividertheme="b"> 
					<li data-theme="b"data-role="list-divider"><? echo $schoolname; ?></li> 
					<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-down-c ui-btn-up-c"><div class="ui-btn-inner ui-li"> <div class="ui-btn-text"><a href="map.php?geo=<? echo $geo; ?>" rel="external" class="ui-link-inherit"><img width=100% height=100% src="<? echo $img ?>" class="ui-li-thumb"></img>
									<h3 class="ui-li-heading">Location:</h3>
					<p class="ui-li-desc"><strong><? echo $addr ?>
</strong></p>
					<p class="ui-li-desc"><? echo $addr2 ?></p>
					
				</a></div><span class="ui-icon ui-icon-arrow-r"></div></li>
			
			<li data-theme="b" class="ui-btn  ui-li ui-btn-down-c ui-btn-up-c"></li>	<? echo "<a href='tel:$tel' data-role='button' data-icon='grid'> Call $abbr</a>"; ?>
			


			<li data-role="list-divider">Map (Click for more)</li> 
<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-down-c ui-btn-up-c">
<a href="map.php?geo=<? echo $geo; ?>" rel="external" class="ui-link-inherit">
		<div class="ui-grid-a">		

		<div class="ui-block-a">	<img width="320px" src="http://maps.google.com/maps/api/staticmap?center=<? echo $geo; ?>&zoom=15.5&format=png&maptype=hybrid&mobile=true&markers=|color:Blue|&size=320x200&key=&sensor=false&key=AIzaSyCOG2byj_OnuUKw5dua6-tz7a3ef7VHN8I" >
</div>
		</div><!-- /grid-a --></a>
<span class="ui-icon ui-icon-arrow-r"></li>	
			<li data-role="list-divider">Information </li> 
<li data-theme="c" class="">
									<h3 class="ui-li-heading">About:</h3>
<p class="ui-li-desc"><strong>Principal: <? echo $pr; ?>
</strong></p>
<p class="ui-li-desc">Administrative-Secretary: <? echo $ar; ?>
</p>
								</ul><br>
<div data-role="controlgroup" data-theme="a" align="center" data-type="horizontal"> 
<div class="ui-btn-text"><a href="map.php?geo=<? echo $geo; ?>" rel="external" class="ui-link-inherit" data-role=button data-icon="search"> Map</a> 
						

		</div> 
	</div><!-- /content --> 
 
	

  </body>
</html>
