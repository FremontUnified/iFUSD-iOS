<!DOCTYPE HTML>
<html> 
   <head> 
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

   <title>Fremont Unified - Sumukh Sridhara</title> 

<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.css" />

<script src="http://code.jquery.com/jquery-1.5.2.min.js"></script>


<script src="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.js"></script>
</head> 


<div data-role="page" > 
 
	<div data-role="header"  data-theme="b" data-backbtn="false"> 
				<h1>About</h1> 
	</div><!-- /header --> 
 
	<div data-role="content" data-theme="b">	
	Development/Interface: Sumukh Sridhara <BR>	 

</div><!-- /content --> 
	<div data-role="footer" data-theme="b" align=center>	
Click on the X above to close
</div><!-- /footer --> 






</div>

</body>