<!DOCTYPE HTML>
<html>
  <head>
    <meta name="viewport" content="width=320px; user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
<meta names="apple-mobile-web-app-status-bar-style" content="black-translucent" />

    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <title>Sumukh Sridahra</title>
    
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0b1/jquery.mobile-1.0b1.min.css">
	    <link rel="stylesheet" href="mapapp.css" type="text/css">

	<script src="http://code.jquery.com/jquery-1.6.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.0b1/jquery.mobile-1.0b1.min.js"></script>
	 <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
	 	<script type="text/javascript" src="ui/jquery.ui.map.min.js"></script>



	<script type="text/javascript" charset="utf-8" src="mapapp.complete.js"></script>

	</head>
  <body>
	<div data-role="page" data-theme="b" id="page-home">
	<!-- <div data-role="header" data-theme="b">
	<h1>
	MSJE
	</h1>
	</div> -->
	<div data-role="content" id="contenthome">
<ul data-role="listview"  data-theme="c" data-dividertheme="b"> 
					<li data-theme="b"data-role="list-divider">Mission San Jose Elementary</li> 
					<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-down-c ui-btn-up-c"><div class="ui-btn-inner ui-li"> <div class="ui-btn-text"><a href="#page-map" class="ui-link-inherit"><img width=100% height=100% src="http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/msje_sign.jpg" class="ui-li-thumb"></img>
									<h3 class="ui-li-heading">Location:</h3>
					<p class="ui-li-desc"><strong>43545 Bryant Street
</strong></p>
					<p class="ui-li-desc">Fremont,CA 94539</p>
					
				</a></div><span class="ui-icon ui-icon-arrow-r"></div></li>
			
			<li data-theme="b" class="ui-btn  ui-li ui-btn-down-c ui-btn-up-c"></li>	<a href="tel:+1-510-656-1200" data-role="button" data-icon="grid">Call MSJE</a>
			


			<li data-role="list-divider">Map (Click for more)</li> 
<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-down-c ui-btn-up-c"><a href="#page-map" class="ui-link-inherit">
<P></P>
		<div class="ui-grid-a">		
	
		<div class="ui-block-a"><div align="center" id="map_square"></div></div>
		</div><!-- /grid-a --></a>
<span class="ui-icon ui-icon-arrow-r"></li>	
			<li data-role="list-divider">Information </li> 
<li data-theme="c" class="">
									<h3 class="ui-li-heading">About:</h3>
<p class="ui-li-desc"><strong>Principal: Bonnie Curtis
</strong></p>
					<p class="ui-li-desc">Administrative Secretary: Shanthika <br> Sukumar
</p>
								</ul>
								<br>

		<div data-role="controlgroup" data-theme="a" align="center" data-type="horizontal">
			<a href="<?php echo "javascript:history.go(-1)"; ?>" data-role=button data-icon="back">Back</a>
			<a href="#page-map" data-role=button data-icon="search"> Directions</a>
			<a  data-rel="dialog" href="about.php" data-theme="b"  data-role=button data-icon="info">About</a>
		</div>
	</div><!-- /content -->

	<div data-role="footer" data-position="static" align ="center">
		  <a data-icon="back" href="<?php echo "javascript:history.go(-1)"; ?>" data-theme="b"> Go Back  </a>   <a data-icon="star" data-rel="dialog" href="about.php" data-theme="b"> About  </a> 	</div><!-- /footer -->	
	</div><!-- /page-home -->

	<div data-role="page" data-theme="c" data-fullscreen="true" id="page-map">

	<div data-role="content" class="map-content">
		<div data-role="header" data-theme="c" data-position="static">
	<div data-role="navbar">
	<ul>
    	    	<li><a data-rel="dialog" href="#page-mao">Ma</a></li>

    	<li><a href="#page-home">Back</a></li>
    	<li><a href="#page-map" class="refresh">Refresh</a></li>
	</ul>
	</div><!-- /navbar -->
	</div><!-- /footer -->
<br><br>
		<div id="map_canvas"></div>
	</div><!-- /content -->
	
	</div><!-- /page-map -->

	<div data-role="page" data-theme="b" data-fullscreen="true" id="page-dir">
			<div data-role="header" data-theme="b"  data-position="static">
			<h1>Directions</h1></div> 

	<div data-role="content">
		<div id="dir_panel">
</div>

	</div><!-- /content -->

	<div data-role="footer" data-theme="b" data-position="static">
	<div data-role="navbar">
		<ul>
    	<li><a href="#page-home">Back</a></li>
    	<li><a href="#page-map">Map</a></li>
		</ul>
	</div><!-- /navbar -->
	</div><!-- /footer -->
	</div><!-- /page-dir -->

  </body>
</html>
