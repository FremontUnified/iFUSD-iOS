var mapdata = { destination: new google.maps.LatLng(37.52920, -121.96340
) };

// Start page
$('#page-home').live("pagecreate", function() {
	$('#map_square').gmap(
	        { 'center' : mapdata.destination, 
	          'zoom' : 14, 
	          'mapTypeControl' : false, 
	          'navigationControl' : false,
	              'panControl' : false,

	          'streetViewControl' : false, 
	          'mapTypeId' : google.maps.MapTypeId.ROADMAP,

	          'callback' : function(map) {
	              $('#map_square').gmap('addMarker', 
	                  { 'position' : map.getCenter(), 
	                      'draggable':false,

	                    'animation' : google.maps.Animation.DROP,
	                          'title':"School!"

	                   });
	         }

	    });

    $('#map_square').click( function() { 
        $.mobile.changePage('#page-map', 'slideup');
    });
});

//Create the fullscreen map, request display of directions
$('.refresh').live("click", function() {
    $('#map_canvas').gmap({
        'callback' : function(map) {
      //    START: Tracking location with device geolocation
    if ( navigator.geolocation ) { 
                navigator.geolocation.getCurrentPosition ( 
                    function(position) {
                        $('#map_canvas').gmap('displayDirections', 
                        { 'origin' : new google.maps.LatLng(position.coords.latitude, position.coords.longitude), 
                          'destination' : mapdata.destination, 'travelMode' : google.maps.DirectionsTravelMode.DRIVING},
                        { 'panel' : document.getElementById('dir_panel')},
                              function (success, result) {
                                  if (success) {
                                  var center = result.routes[0].bounds.getCenter();
                                   $('#map_canvas').gmap('option', 'center', center);
                                   $($('#map_canvas').gmap('getMap')).triggerEvent('resize');
                                  }  else {
                                    alert('Unable to get locations');
                               	    

                                  
                                                       }
                              }
                           );         
                    },  
                    function(){ 
                        alert('Uh-oh! We did not get your current location. You might have location services turned off or we did not get your permission to use your location. We collect your location only to give your driving directions!');
                       $.mobile.changePage('#page-home', 'slide'); 
                    }); 
                }            
          // END: Tracking location with device geolocation

     /*       // START: Tracking location with test lat/long coordinates
            // Toggle between two origins to test refresh, force new route to be calculated
            var position = {};
                position = { coords: { latitude: 37.50775134622558, longitude: -121.95500135421753 } }; 
           
            $('#map_canvas').gmap('displayDirections', 
                { 'origin' : new google.maps.LatLng(position.coords.latitude, position.coords.longitude), 
                  'destination' : mapdata.destination, 
                  'travelMode' : google.maps.DirectionsTravelMode.DRIVING},
                  { 'panel' : document.getElementById('dir_panel')},
                  function (success, result) {
                      if (success) {
                          var center = result.routes[0].bounds.getCenter();
                          $('#map_canvas').gmap('option', 'center', center);
                          $($('#map_canvas').gmap('getMap')).triggerEvent('resize');
                      } else {
                          alert('Unable to get route');
                      }
                  });
        */    // END: Tracking location with test lat/long coordinates
        }
    });
    return false;
});

// Map page
$('#page-map').live("pagecreate", function() {
    $('.refresh').trigger('click');
});

// Go to map page to see instruction detail (zoom) on map page
$('#dir_panel').live("click", function() {
    $.mobile.changePage('#page-map', 'slide');
});
// Briefly show hint on using maps
$('#page-map').live("pageshow", function() {
    $("<div class='ui-loader ui-overlay-shadow ui-body-e ui-corner-all'><h1>"
            + "Loading Maps!" + "<br>" + "Use multitouch to navigate! Tap on Directions to see driving directions" +"</h1></div>")
    .css({ "display": "block", "opacity": 0.95, "top": $(window).scrollTop() + 120})
    .appendTo( $.mobile.pageContainer )
    .delay( 3000 )
    .fadeOut( 900, function(){
        $(this).remove();
   });
});

// Briefly show hint on using instruction tap/zoom
$('#page-dir').live("pagebeforeshow", function() {
    $("<div class='ui-loader ui-overlay-shadow ui-body-e ui-corner-all'><h1>"
            + "Loading Directions!" + "<br>" + "Tap on any step to load that step on the map" +"</h1></div>")
    .css({ "display": "block", "opacity": 0.9, "top": $(window).scrollTop() + 300 })
    .appendTo( $.mobile.pageContainer )
    .delay( 3500 )
    .fadeOut( 800, function(){
        $(this).remove();
   });
});
