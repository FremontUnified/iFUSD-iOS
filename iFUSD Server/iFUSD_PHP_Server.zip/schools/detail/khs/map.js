
//thx @elroyjetson for the code example

// When map page opens get location and display map
$('.page-map').live("pagecreate", function() {

	//school :)
	//var lat = 37.5282697, lng = -121.9219029;
	 
       
    /* //try to get GPS coords
	if( navigator.geolocation ) {
			
		//redirect function for successful location	
		function gpsSuccess(pos){
			if( pos.coords ){ 
				lat = pos.coords.latitude;
				lng = pos.coords.longitude;
			}
			else{
				lat = pos.latitude;
				lng = pos.longitude;
			}
		}	
		
		function gpsFail(){
			//Geo-location is supported, but we failed to get your coordinates. Workaround here perhaps?
		}
		
		navigator.geolocation.getCurrentPosition(gpsSuccess, gpsFail, {enableHighAccuracy:true, maximumAge: 300000});
	}
*/
	/*
	if not supported, you might attempt to use google loader for lat,long
	$.getScript('http://www.google.com/jsapi?key=YOURAPIKEY',function(){
		lat = google.loader.ClientLocation.latitude;
		lng = google.loader.ClientLocation.longitude;
	});			
	*/
    var school = new google.maps.LatLng(37.52956, -121.98600
);

	var latlng = new google.maps.LatLng(37.52956, -121.98600
);	var myOptions = {
		zoom: 18,
		center: latlng,
		       zoomControl: true,
              zoomControlOptions: {
        style: google.maps.ZoomControlStyle.LARGE
        },


		mapTypeId: google.maps.MapTypeId.HYBRID
	
    };
    var map = new google.maps.Map(document.getElementById("map-canvas"),myOptions);
      marker = new google.maps.Marker({
    map:map,
    draggable:false,
    animation: google.maps.Animation.DROP,

    position: school
  });

});