<? 
$schoolname = "Hopkins Junior High";
$abbr = "Hopkins";
$addr = "600 Driscoll Road";
$addr2= "Fremont, CA 94539";
$tel="15106563500";
$img = "http://www.fremont.k12.ca.us/cms/lib04/CA01000848/Centricity/Domain/5/Hopkins.jpg";
$pr = "Mary Miller";
$as = "Susan Hall";


?>
<!DOCTYPE HTML>
<html>
  <head>
    <meta name="viewport" content="width=320px; user-scalable=yes" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
<meta names="apple-mobile-web-app-status-bar-style" content="black-translucent" />

    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <title>FUSD</title>
    
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0b1/jquery.mobile-1.0b1.min.css">
	    <link rel="stylesheet" href="mapapp.css" type="text/css">

	<script src="http://code.jquery.com/jquery-1.6.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.0b1/jquery.mobile-1.0b1.min.js"></script>
	 <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
	 	<script type="text/javascript" src="ui/jquery.ui.map.min.js"></script>
	<script src="http://maps.google.com/maps/api/js?sensor=true"></script> 



	<script type="text/javascript" charset="utf-8" src="mapapp.complete.js"></script>

	</head>
  <body>
	<div data-role="page" data-theme="b" id="page-home">
<!--	<div data-role="header" data-theme="b">
	<h1>
School
	</h1>
	</div> -->
	<div data-role="content" id="contenthome">

				<ul data-role="listview" data-theme="c" data-dividertheme="b"> 
					<li data-theme="b"data-role="list-divider"><? echo $schoolname; ?></li> 
					<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-down-c ui-btn-up-c"><div class="ui-btn-inner ui-li"> <div class="ui-btn-text"><a href="map.html" class="ui-link-inherit"><img width=100% height=100% src="<? echo $img ?>" class="ui-li-thumb"></img>
									<h3 class="ui-li-heading">Location:</h3>
					<p class="ui-li-desc"><strong><? echo $addr ?>
</strong></p>
					<p class="ui-li-desc"><? echo $addr2 ?></p>
					
				</a></div><span class="ui-icon ui-icon-arrow-r"></div></li>
			
			<li data-theme="b" class="ui-btn  ui-li ui-btn-down-c ui-btn-up-c"></li>	<? echo "<a href='tel:$tel' data-role='button' data-icon='grid'> Call $abbr</a>"; ?>
			


			<li data-role="list-divider">Map (Click for more)</li> 
<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-down-c ui-btn-up-c"><a rel="external" href="map.html" class="ui-link-inherit">
<P></P>
		<div class="ui-grid-a">		
	
		<div class="ui-block-a"><div id="map_square"></div></div>
		</div><!-- /grid-a --></a>
<span class="ui-icon ui-icon-arrow-r"></li>	
			<li data-role="list-divider">Information </li> 
<li data-theme="c" class="">
									<h3 class="ui-li-heading">About:</h3>
<p class="ui-li-desc"><strong>Principal: <? echo $pr; ?>
</strong></p>
<p class="ui-li-desc">Administrative-Secretary: <? echo $as; ?>
</p>
								</ul><br>
<div data-role="controlgroup" data-theme="a" align="center" data-type="horizontal"> 
			<a href="javascript:history.go(-1)" data-role=button data-icon="back">Back</a> 
			<a href="map.html" data-role=button data-icon="search"> Map</a> 

		</div> 
	</div><!-- /content --> 
 
	<div data-role="footer" data-position="static" align ="center"> 
		  <a data-icon="back" href="javascript:history.go(-1)" data-theme="b"> Go Back  </a>   	</div><!-- /footer -->	
	</div><!-- /page-home --> 
	

  </body>
</html>
