<!DOCTYPE HTML>
<html> 
   <head> 
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

   <title>Fremont Unified</title> 
<meta name="viewport" content = "width = device-width, user-scalable = no" />  
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0b1/jquery.mobile-1.0b1.min.css">
	<script src="http://code.jquery.com/jquery-1.6.1.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.0b1/jquery.mobile-1.0b1.min.js"></script>
	
</head>
</head> 

<body>

<div data-role="page" > 
 
	<div data-role="header"  data-theme="b"> 
					<a href="index.php" class="ui-btn-left"  data-theme="e" data-icon='arrow-l'  

           data-direction="reverse">Back</a><h1>Fremont Unified </h1> 
	
	</div><!-- /header --> 
 
	<div data-role="content" data-theme="b">	
<TD style="VERTICAL-ALIGN: top"><SPAN style="FONT-SIZE: 10pt"><SPAN style="FONT-SIZE: 10pt"><STRONG>Other Programs/Schools</STRONG></SPAN></SPAN></TD> <BR><BR>
<TD style="VERTICAL-ALIGN: top"><SPAN style="FONT-SIZE: 10pt"><SPAN style="FONT-SIZE: 10pt"><A href="http://www.fmtusd.org/site/Default.aspx?PageID=10910">Course Program</A> (See Robertson)</SPAN><A href="http://www.fmtusd.org/site/Default.aspx?PageID=643"></A></SPAN></TD><BR>
<TD style="VERTICAL-ALIGN: top"><SPAN style="FONT-SIZE: 10pt"><SPAN style="FONT-SIZE: 10pt"><A href="http://www.fmtusd.org/site/Default.aspx?PageID=643">Adult School</A></SPAN></SPAN></TD><BR>
<TD style="VERTICAL-ALIGN: top" colSpan=2><SPAN style="FONT-SIZE: 10pt"><SPAN style="FONT-SIZE: 10pt"><A href="http://coil.schoolwires.net/coil/site/default.asp" target=_blank>COIL</A> - Circle of Independent Learning</SPAN></SPAN></TD></TR><BR>
<TD style="VERTICAL-ALIGN: top"><SPAN style="FONT-SIZE: 10pt"><SPAN style="FONT-SIZE: 10pt"><A href="http://www.fmtusd.org/site/Default.aspx?PageID=10910">Course Program</A> (See Robertson)</SPAN><A href="http://www.fmtusd.org/site/Default.aspx?PageID=643"></A></SPAN></TD><BR>
<TD style="VERTICAL-ALIGN: top"><SPAN style="FONT-SIZE: 10pt"><SPAN style="FONT-SIZE: 10pt"><A href="http://www.fmtusd.org/site/Default.aspx?PageID=265">Native American</A></SPAN></SPAN></TD><BR>
<TD style="VERTICAL-ALIGN: top"><SPAN style="FONT-SIZE: 10pt"><SPAN style="FONT-SIZE: 10pt"><SPAN style="FONT-SIZE: 10pt"><A href="http://www.fmtusd.org/site/Default.aspx?PageID=266">State PreSchool</A></SPAN></SPAN></SPAN></TD><BR>
<TD style="VERTICAL-ALIGN: top"><SPAN style="FONT-SIZE: 10pt"><SPAN style="FONT-SIZE: 10pt"><A href="#">Summer School</A></SPAN><A href="http://www.fmtusd.org/site/Default.aspx?PageID=265"></A></SPAN></TD><BR>
<TD style="VERTICAL-ALIGN: top"><SPAN style="FONT-SIZE: 10pt"><SPAN style="FONT-SIZE: 10pt"><SPAN style="FONT-SIZE: 10pt"><SPAN style="FONT-SIZE: 10pt"><A href="http://www.fmtusd.org/site/Default.aspx?PageID=225" target=_blank>Teen Parent/Cal Safe</A></SPAN></SPAN><A href="http://www.fmtusd.org/site/Default.aspx?PageID=266"></A></SPAN></SPAN></TD><BR>
<TD style="VERTICAL-ALIGN: top"><SPAN style="FONT-SIZE: 10pt"><SPAN style="FONT-SIZE: 10pt"><SPAN style="FONT-SIZE: 10pt"><A href="http://www.fmtusd.org/site/Default.aspx?PageID=11136">Vista Alternative</A></SPAN><A href="http://www.fmtusd.org/site/Default.aspx?PageID=225" target=_blank></A></SPAN></SPAN></TD><BR>






</div><!-- /content --> 

<? include('footer.php'); ?>
