<? include('header.php'); ?>
<body class="ui-mobile-viewport">

<div data-role="page" id="page" class="ui-page ui-body-c ui-page-active" "> 
				<div data-role="header"  data-theme="b"> 
				<a href="index.php" class="ui-btn-left"  data-theme="e" data-icon='arrow-l'  

           data-direction="reverse">Back</a><h1>High Schools</h1> 
	
	</div><!-- /header --> 

	<div data-role="content" class="ui-content" role="main">
	 

<div class="content-primary">	

	<ul data-role="listview" data-filter="true" data-filter-placeholder="Search schools..." data-filter-theme="d" class="ui-listview">
				
				
				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-down-undefined ui-btn-up-undefined">A</li>
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><div class="ui-btn-inner ui-li"><div class="ui-btn-text"><a rel="external" href="detail/ahs/" class="ui-link-inherit">American High</a></div><span class="ui-icon ui-icon-arrow-r"></span></div></li>

				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">I</li>
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><div class="ui-btn-inner ui-li"><div class="ui-btn-text"><a rel="external" href="detail/ihs/"  class="ui-link-inherit">Irvington High</a></div><span class="ui-icon ui-icon-arrow-r"></span></div></li>

				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">K</li>

				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><div class="ui-btn-inner ui-li"><div class="ui-btn-text"><a rel="external" href="detail/khs/" class="ui-link-inherit">Kennedy High</a></div><span class="ui-icon ui-icon-arrow-r"></span></div></li>
			
				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">M</li>

				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><div class="ui-btn-inner ui-li"><div class="ui-btn-text"><a rel="external" href="detail/msjhs/" class="ui-link-inherit">Mission San Jose High</a></div><span class="ui-icon ui-icon-arrow-r"></span></div></li>

				
				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">R</li>
				
				
				
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><div class="ui-btn-inner ui-li"><div class="ui-btn-text"><a rel="external" href="detail/rhs/" class="ui-link-inherit">Robertson High</a></div><span class="ui-icon ui-icon-arrow-r"></span></div></li>
				
				<li data-role="list-divider" role="heading" class="ui-li ui-li-divider ui-btn ui-bar-b ui-btn-up-undefined">W</li>
				<li data-theme="c" class="ui-btn ui-btn-icon-right ui-li ui-btn-up-c"><div class="ui-btn-inner ui-li"><div class="ui-btn-text"><a rel="external" href="detail/whs/" class="ui-link-inherit">Washington High</a></div><span class="ui-icon ui-icon-arrow-r"></span></div></li>
			</ul>
			</div>			
				<div data-role="footer" data-theme="b" align="center" data-position="fixed" class="ui-bar-b ui-footer ui-footer-fixed ui-fixed-inline fade" role="contentinfo">	



</div>



</div>


</div><div class="ui-loader ui-body-a ui-corner-all" style="top: 213.5px; "><span class="ui-icon ui-icon-loading spin"></span><h1>loading</h1></div></body>				<div data-role="footer" data-theme="b" align=center data-position="static">	
	<a href="javascript: history.go(-1)"> Back </a> 
</div><!-- /footer --> 






</div>

</body>
</html>