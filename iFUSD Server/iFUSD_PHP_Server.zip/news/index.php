<!DOCTYPE html>  

<html>  
   <head>  
   <meta charset="utf-8">  
  
   <title>FUSD</title>   
  
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.css" />
<script src="http://code.jquery.com/jquery-1.5.2.min.js"></script>
<script src="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.js"></script>
</head>  

<body>

<div data-role="page" > 
 
	<div data-role="header"  data-theme="b" data-position="fixed"> 
				<h1>Fremont Unified</h1> 
	
	</div><!-- /header --> 
 
	<div data-role="content" data-theme="b">	
	 
	You've loaded the wrong page. Maybe site.php? 
	<br>
	<br>
</div><!-- /content --> 
	<div data-role="footer" data-theme="b">	
	<p align="center">Footer</p>
</div><!-- /footer --> 






</div>

</body>