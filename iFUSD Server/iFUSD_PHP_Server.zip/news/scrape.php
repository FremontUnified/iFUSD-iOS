<?php
//  Advanced cURL Scrape
//  Obtain data from url and force links to work
//  This code was written by Michael Devaney
//  Note: You might want to cache this
//  All I ask is that you do not remove these notes
//  Thank you
//$url = $_GET["url"];
//$url= urlencode($_GET["url"]);
$url = "www.fremont.k12.ca.us/site/default.aspx?PageType=3&ModuleInstanceID=4613&ViewID=047E6BE3-6D87-4130-8424-D8E4E9ED6C2A&RenderLoc=0&FlexDataID=20581&PageID=1";
$ch = curl_init ($url); //URL to Scrape
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$page = curl_exec($ch);

preg_match('# <div class="ui-widget app flexpage"[^>]*>(.+?)<div class="ui-widget-footer">#is', $page, $matches, $links); // grabs anything between <p> </p> tags
foreach ($matches as &$match) {
        $match = str_replace('src="/cms/lib','src="http://www.fremont.k12.ca.us/cms/lib/', $match);        
	//This is used to make sure links work.
}
// output html, styles, and more.
echo '<!DOCTYPE HTML>
<html>  
   <head>  
   <meta charset="utf-8">  
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" />

   <title>FUSD</title>   
  
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.css" />
<script src="http://code.jquery.com/jquery-1.5.2.min.js"></script>
<script src="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.js"></script>
</head>  

<body>

<div data-role="page" > 
 
	<div data-role="header"  data-theme="b" data-position="fixed"> 
				<h1>Fremont Unified</h1> 
	
	</div><!-- /header --> 
 
	<div data-role="content" data-theme="b">';
echo $matches[1]; // change [1] to [2] If you want to grab data between the second <p></p> tags  
echo '	 <br>
	</div><!-- /content --> 
	<div data-role="footer" data-theme="b">	
	  FUSD | Sumukh Sridhara
</div><!-- /footer --> 






</div>

</body>
</html>';
?>