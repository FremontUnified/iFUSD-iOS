<?php include('includes/header.php'); ?>

<body> 

<div id="page" data-role="page">

   <!-- <header data-role="header" data-theme="b">
      <h1>Fremont Unified </h1>
   </header><!-- /header -->

   <div data-role="content">	
      <ul data-role="listview" data-theme="c" data-dividertheme="d" data-counttheme="e">
			 <?php
            foreach($feed->query->results->item as $item) {
            //   if ( $siteName === 'psdtuts' ) $comments = $item->comments->content;
              // else $comments = $item->comments[1];
            ?>

            <li>
                    <a href="article.php?siteName=news&origLink=<?php echo urlencode($item->link);?>">
<h2>
                                   <?php echo $item->title; ?>
              </h2>
       <!--       <span class="ui-li-count"> </span> -->
                    </a>

           </li>
                 
      <?php  } ?>

      </ul>
   </div><!-- /content -->

   <footer data-role="footer" data-theme="b" align=center>
<?php 
$h = date(h) - 1;
 echo(date("F dS  Y $h:i:s A ")); ?>
    </footer>
</div><!-- /page -->

</body>
</html>


