<!DOCTYPE html> 
<html> 
   <head> 
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="width=320;" id="viewport" /> 

   <title>Fremont Unified School</title> 

<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.css" />
   <link rel="stylesheet" href="css/mobile.css" />
   <link rel="stylesheet" href="css/article.css" />


<script src="http://code.jquery.com/jquery-1.5.2.min.js"></script>

<script src="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.js"></script>
<script src="http://ifusd.fremontunified.org/fusdweb/quicktap.js"></script>

</head> 
<?php
$url = $feed->link;
$ch = curl_init ($url); //URL to Scrape
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$page = curl_exec($ch);

preg_match('#<div class="ui-widget app headlines detail"[^>]*>(.+?)<div class="ui-widget-footer">#is', $page, $matches, $links); // grabs anything between <p> </p> tags
foreach ($matches as &$match) {

 $match = str_replace("<table ","<", $match);


    $match = str_replace('href="/', 'href="http://www.fmtusd.org/', $match); 
        $match = str_replace('src="/cms/lib','src="http://www.fremont.k12.ca.us/cms/lib/', $match);        

	//This is used to make sure links work.
}
// output html, styles, and more.


?>
<body> 

<div data-role="page" id="page" data-back-btn-text="News!" data-back-btn-theme="e">

   <header data-role="header" data-theme="b" >
     <h2> FUSD News</h2> 
   </header><!-- /header -->

   <div data-role="content" data-theme="c" width="320px" >
<? echo $matches[1]; // change [1] to [2] If you want to grab data between the second <p></p> tags  
?>
 </div><!-- /content -->
   <footer data-role="footer" data-theme="b">
     <div align="center">  iFUSD   </div> </footer>
</div><!-- /page -->



</body>
</html>


