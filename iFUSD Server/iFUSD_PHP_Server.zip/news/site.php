<?php
// If "siteName" isn't in the querystring, set the default site name to 'nettuts'
$siteName = empty($_GET['siteName']) ? 'news' : $_GET['siteName'];

$siteList = array(
   'news',
);

// For security reasons. If the string isn't a site name, just change to 
// nettuts instead.
if ( !in_array($siteName, $siteList) ) {
   $siteName = 'news';
}

$cache = dirname(__FILE__) . "/cache/$siteName";  
// Re-cache every three hours  
if( 1==1 ) {  
 // grab the site's RSS feed, via YQL  {
   // Get from server
   if ( !file_exists(dirname(__FILE__) . '/cache/') ) {
      mkdir(dirname(__FILE__) . '/cache/', 777);
   }
   // YQL query (SELECT * from feed ... ) // Split for readability
   $path = "http://query.yahooapis.com/v1/public/yql?q=";
   $path .= urlencode("SELECT * FROM feed WHERE url='http://feeds.feedburner.com/FUSD$siteName'");
   //using feed burner instead of native feed. the site name variable is news in this case. 
   $path .= "&format=json";

   // Call YQL, and if the query didn't fail, cache the returned data
   $feed = file_get_contents($path, true);

   // If something was returned, cache
   }
else
{
   // We already have local cache. Use that instead.
}

// Decode that shizzle
$feed = json_decode($feed);


// Include the view
include('views/site.tmpl.php');

