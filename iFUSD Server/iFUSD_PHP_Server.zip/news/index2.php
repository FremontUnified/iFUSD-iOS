
<!DOCTYPE html> 
<html> 
	<!-- 
		Copyright 2011 Brendan LaMarche 
		http://www.appin8.com
		
		Approx 4 Hours
		
		License: GPLv3
	--> 
	<head> 
		<title>RSS Mobile Reader</title> 
		<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.css" /> 
		<script type="text/javascript" src="https://www.google.com/jsapi?key=ABQIAAAAuvAXPRXL9qkzO0R8vzYpOhQ_BAnb8hQeSCQ2aBH79hHa1YbW_RQNN9ClKXG21xQObiXJ7diAAYaywg"></script> 
		<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script> --> 
		<script src="http://code.jquery.com/jquery-1.5.2.min.js"></script> 
		<script type="text/javascript"> 
		<!--
			//INIT
			$(document).bind("mobileinit", function(){
			  	$.extend(  $.mobile , {
					defaultTransition: "slide"
			  	}); 
			  
			  	//init local storage feeds
			  	if ( typeof localStorage["feeds"] == "undefined")
			  	{
			    	restoreDefault();
			  	}
			});
			
			$(document).ready(function(){
				//load local storage feeds
				var feeds = eval(localStorage["feeds"]);
			  	if (feeds!=null)
				for (var i=0; i<feeds.length;i++)
			  	{
			  		//create buttons for rss feed
			  		$("#yourfeeds").append('<input data-icon="arrow-r" data-iconpos="right" type="button" feed="'+localStorage.feeds[i]+'" onclick="loadFeed(\''+feeds[i]+'\');" value="'+feeds[i]+'" />');
			  		$("#deletefeedlist").append('<input data-icon="delete" data-iconpos="right" type="button" feed="'+localStorage.feeds[i]+'" onclick="deleteFeed(\''+feeds[i]+'\');" value="'+feeds[i]+'" />');
			  	}
			});
			
			//FUNCS
			function restoreDefault()
			{
				localStorage.clear();
				var feeds= new Array();
				feeds.push("http://www.fmtusd.org/site/RSS.aspx?DomainID=1&ModuleInstanceID=4613&PageID=1");
				
				localStorage.setItem("feeds", JSON.stringify(feeds));
				window.location.reload();
			}
			
			function loadFeed(url)
			{
				var rnd=Math.floor(Math.random()*10000000);
				$(document.body).append('<div data-role="page" id="results'+rnd+'" data-theme="b">'+$("#results").html()+'</div>');
				
				var feed = new google.feeds.Feed(url);
				feed.setNumEntries(30);
				feed.load(function(result) {
					if (!result.error) 
					{
						$("#results"+rnd+" .resultscontent").append('<div data-role="controlgroup" class="articlelist"></div>');
					  	for (var i = 0; i < result.feed.entries.length; i++) {
							$("#results"+rnd+" .resultscontent .articlelist").append('<input data-icon="arrow-r" data-iconpos="right" onclick=\'showArticle("'+escape(result.feed.entries[i].title)+'","'+escape(result.feed.entries[i].link)+'","'+escape(result.feed.entries[i].content)+'")\' type="button" value="' + result.feed.entries[i].title.replace(/"/g, "'") + '" />');
						}
						$("#results"+rnd+" .feedtitle").html(url);
						$.mobile.changePage($("#results"+rnd),"slide",false,true);
					}
					else
						alert('feed error');
				});
			}
			
			function showArticle(title, url, desc)
			{
				if (typeof desc=="undefined")
					desc="(No description provided)";
				$("#article .articleinfo").html("<p>"+unescape(title)+"</p><p>"+unescape(desc)+"</p><p><a target=\"_blank\" href=\""+unescape(url)+"\">"+unescape(url)+"</a></p>");
				$.mobile.changePage("#article","slide",false,true);
			}
			
			function addTheFeed()
			{
				var url = $("#rssFeed").val();			
				if (url==""){
					$.mobile.changePage("#main","slide",true,true);
				}
				else 
				{				
					var feeds = eval(localStorage["feeds"]);
					feeds.push(url);
					localStorage.setItem("feeds", JSON.stringify(feeds));
					
					window.location.reload();
				}
			}
			
			function deleteFeed(url)
			{		
				if (url==""){
					$.mobile.changePage("#main","slide",true,true);
				}
				else 
				{		
					var feeds = eval(localStorage["feeds"]);
					for (var i=0; i<feeds.length; i++)
					{
						if (feeds[i]==url) {
							feeds.splice(i,1);
							break;
						}
					}
					localStorage.setItem("feeds", JSON.stringify(feeds));
					
					window.location.reload();
				}
			}
			
			function HtmlEncode(html) {
			 return $('<div/>').text(html).html();
			}
			
			function HtmlDecode(text) {
			 return $('<div/>').html(text).text();
			}
			
			//google feeds api
			google.load("feeds", "1");
			  	function OnLoad() {}
			google.setOnLoadCallback(OnLoad);
		-->
		</script> 
		<script src="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.js"></script> 
	</head> 
	<body> 
		<div data-role="page" id="main" data-theme="b"> 
			<div data-role="header"><h1>RSS Mobile Reader</h1></div> 
			
			<div data-role="content"> 
				<div data-role="controlgroup" id="yourfeeds"> 
				</div> 
				
				 	
			</div> 
		</div> 
		
		<!-- placeolder for feed template --> 
		<div id="results"> 
			<div data-role="header"><h1 class="feedtitle">Feed</h1></div> 
			
			<div data-role="content" class="resultscontent"> 
			</div> 
			
		</div> 
		<!-- placeolder for feed template --> 
		
		<div data-role="page" id="deletefeeds" data-theme="b"> 
			<div data-role="header"><h1>Delete Feeds</h1></div> 
			
			<div data-role="content"> 
				<h5>Select a feed below to delete it from your list.</h5> 
				<div data-role="controlgroup" id="deletefeedlist"> 
				</div> 
			</div> 
		</div> 
		
		<div data-role="page" id="article" data-theme="b"> 
			<div data-role="header"><h1>Details</h1></div> 
			
			<div data-role="content" class="articleinfo"></div> 
			
		</div> 
		
		<div data-role="page" id="addfeed" data-theme="b"> 
			<div data-role="header"><h1>RSS Mobile</h1></div> 
			
			<div data-role="content"> 
				<div data-role="fieldcontain"> 
					<label for="rssFeed">RSS Feed Url:</label> 
					<input type="text" id="rssFeed" name="rssFeed" value="http://" /> 
				</div> 
				<input type="button" onclick="addTheFeed();" value="Add This Feed" data-iconpos="right" data-icon="check" /> 
			</div> 
			
		</div> 
		
	</body> 
</html>