<? include('header.php'); ?>
<body>

<div id="page" data-role="page" >
 <!--
	<div data-role="header"  data-theme="b"> 
				<h1>Fremont Unified </h1> 
	
	</div><!-- /header --> 
 
	<div data-role="content" data-theme="b">	

	 <ul data-role="listview" class=" ui-listview" data-inset="false" data-theme="c" data-dividertheme="b">
						
						<li class="ui-btn-icon-right"><div  class="ui-btn-text"><a  rel="external" href="resources.php?url=http://www.fmtusd.org/Domain/29" class="ui-link-inherit"><h2 class="ui-li-heading">Parent Resources</h2><p class="ui-li-desc">Lots of Resources for Parents!</p><span class="ui-icon ui-icon-arrow-r"></span></a></div>
</li>						
												<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="http://iparent.fmtusd.org" class="ui-link-inherit"><h2 class="ui-li-heading">iParent</h2><p class="ui-li-desc">Learn more and access iParent on the go!</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>

						
						
	<li class="ui-btn-icon-right"><div class="ui-btn-text"><a  rel="external" href="resources.php?url=http://www.fmtusd.org/Domain/30" class="ui-link-inherit"><h2 class="ui-li-heading">Student Resources</h2><p class="ui-li-desc">Course Catalogs and Resources</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>


	<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="volunteer.php" class="ui-link-inherit"> <h2 class="ui-li-heading">Get Involved</h2><p class="ui-li-desc">Volunteer Opportunities</p><span class="ui-icon ui-icon-arrow-r"></span></a></div>
</li>
	
	
												<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="library.php" rel="external" onClick="(alert('Reminder: Use a Two Finger Horizontal Swipe to navigate Back through webpages'))" class="ui-link-inherit"><h2 class="ui-li-heading">Library</h2><p class="ui-li-desc">Search school libraries!</p><span class="ui-icon ui-icon-arrow-r"></span></a></div>
</li>
												






		</ul></div><!-- /content --> 

<? include('footer.php'); ?>
