
<!DOCTYPE HTML>
<html> 
   <head> 
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

   <title>Fremont Unified - Sumukh Sridhara</title> 
<meta name = "viewport" content = "width=700 initial-scale = 0.8">

<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.css" />

<script src="http://code.jquery.com/jquery-1.5.2.min.js"></script>


<script src="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.js"></script>

</head> 

<body> 

<div data-role="page" > 
 
	<div data-role="header"  data-theme="b"  > 
			 <a rel="external" href='index.php' class='ui-btn-left'data-back-btn-theme="e"  data-icon='arrow-l'>Back</a>	<h1>Fremont Unified</h1> 
	
	</div><!-- /header --> 
 
	<div data-role="content" data-theme="b">	
<?php
$url = $_GET['url'];
$ch = curl_init ($url); //URL to Scrape
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$page = curl_exec($ch);

preg_match('#<div class="SWContentBODY" style="position: relative;"[^>]*>(.+?)<div class="ui-widget-footer">#is', $page, $matches, $links); // grabs anything between <p> </p> tags
foreach ($matches as &$match) {
    $match = str_replace('href="/', 'href="http://www.fmtusd.org/', $match); 
	//This is used to make sure links work.
}
// output html, styles, and more.
echo $matches[1]; // change [1] to [2] If you want to grab data between the second <p></p> tags  

?>

</div>	
	<div data-role="footer" data-theme="b" align=center data-position="static">	
	     <div align="center">iFUSD</div> 

</div><!-- /footer --> 





</div>

</body>
</html>