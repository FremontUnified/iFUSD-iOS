<? include('header.php'); ?>
<body>

<div data-role="page" > 
 
	<div data-role="header"  data-theme="b"> 
			<a href='index.php' class='ui-btn-left ui-btn-back' data-direction="reverse" data-icon='arrow-l'>Back</a>	<h1>Fremont Unified </h1> 
	
	</div><!-- /header --> 
 
	<div data-role="content" data-theme="b">	
	 <ul data-role="listview" class=" ui-listview" data-theme="b">
						
						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="page.php?url=http://www.fmtusd.org/domain/57" class="ui-link-inherit"><h2 class="ui-li-heading">FAQ </h2><p class="ui-li-desc">Questions about Volunteering</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>
					<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="page.php?url=http://www.fmtusd.org/Page/211" class="ui-link-inherit"><h2 class="ui-li-heading">District Opportunities</h2><p class="ui-li-desc">Volunteer on Committees!</p></p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>
						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a href="page.php?url=http://www.fmtusd.org/Page/212" class="ui-link-inherit"> <h2 class="ui-li-heading">School Site</h2><p class="ui-li-desc">Volunteer at Schools!</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>
					






		</ul></div><!-- /content --> 

<? include('footer.php'); ?>
