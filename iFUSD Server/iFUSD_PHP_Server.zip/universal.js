<style> 
* { 
-webkit-touch-callout: none; /* prevent callout to copy image, etc 
when tap to hold */ 
} 

<style> 
