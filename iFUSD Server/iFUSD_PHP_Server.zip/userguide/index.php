
<html>  
   <head>  
   <meta charset="utf-8">  
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" />

   <title>FUSD</title>   
  
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.css" />
<script src="http://code.jquery.com/jquery-1.5.2.min.js"></script>
<script src="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.js"></script>
</head>  

<body>

<div data-role="page" > 
 
 
	<div data-role="content" data-theme="b">	
	 
	 Here are some tips:
	 <ul>
	 <li>
	 Shake your device to return home at any time. Go to Settings if you want to turn this feature off	 </li>
	 <li>
	 Choose whether to receive notifications sounds in your iOS Settings > Notifications.
	 </li>
	 	 <li>
Choose your attendance area for push notifications in the Settings module.	You can choose to receive notifications concerning an attendance area, or about one school.  </li>
 <li>
Please Send your Feedback in Preferences</li>

	</ul>
	<br>
	<br>
</div><!-- /content --> 
	<div data-role="footer" data-theme="b" align="center">	
	 iFUSD
</div><!-- /footer --> 






</div>

</body>