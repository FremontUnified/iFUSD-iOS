<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>About</title>
	<link rel="stylesheet" href="stylesheets/iphone.css" />
	<!-- for profile image -->
	<style type="text/css" media="screen">
		li.picture { background: url(57.png) no-repeat !important; }
	</style>
	<!-- end line customization -->
</head>

<body>
<ul class="profile">
	<li class="picture"></li>
	<li class="clearfix"><h2>iFUSD for iOS</h2><p>Fremont Unified School District</p>
	<BR>
	<h2 align="center">About the team </h2>
	<p align="center">Tap on a name to find out more</p>
	</li>
</ul>
<br>
<ul class="field">
	<li class="arrow"><h3>FUSD CTO</h3> <a href="javascript:alert('John Krull is the CCTO (Certified Chief Technology Officer) for the Fremont Unified School District.')">John Krull</a></li>
	<li class="arrow"><h3>Consultant</h3> <a href="javascript:alert('Rajan is a cofounder of a local IT company and is a Parent and Community Member')">Rajan Barma</a></li>
	<li class="arrow"><h3>Developer </h3> <small>Student</small> <a href="javascript:alert('Sumukh designed and developed iFUSD. He is a high school student at Mission San Jose High. ')"> <b> Sumukh Sridhara </b></a></li>

	<li class="arrow"><h3 align="right">PM</h3><small>Student</small><a href="javascript:alert('Andrew is the Product Manager for iFUSD. He is also a student at Mission San Jose High.')">Andrew Han</a></li>
	
</ul>
<ul class="data">
	<li><p>The iFUSD application was created to provide the local community with a quick, convenient way to stay connected to the FUSD. As a technologically progressive district, the FUSD is the first school district in California to develop a mobile app for the App Store. The application places official FUSD website and FUSD calendar at your finger tips. iFUSD  offers push notifications, an instantaneous way to update users of important events. Created by a small team consisting of a devoted FUSD administrator, an involved parent, and two high school students, the FUSD iOS application hopes to provide a convenient and practical means of communication for community members. </p></li>
</ul>
<ul class="field">

	<li><h3>Notes</h3> <big> Various Open Source Project Were Used for this project. For more info, please contact the<a href="mailto:Sumukh@sumukhsridhara.com"> developer</a><!-- The following Open Source Projects were used or modified for this project:<br>
	 1. iRate <br>
	 2. ReachTest (By Sumukh Sridhara) <br>
	 3. jQuery<br>
	 4.GCDiscreetNotificationView <br>
	 5. WToast<br>
	  6.InAppSettingsKit  <br> --> </big></li>
</ul>


<p><strong>Fremont Unified School District</strong><br/>4210 Technology Drive
Fremont, CA 94538                       
 <br>(<a href="tel:15106572350">(510) 657-2350</a>)</p>



</body>
</html>