<?php
//  Advanced cURL Scrape
//  Obtain data from url and force links to work


$url = $_GET["url"];
$ch = curl_init ($url); //URL to Scrape
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$page = curl_exec($ch);

preg_match('#<div class="ui-article"[^>]*>(.+?)</p>#is', $page, $matches, $links); // grabs anything between <p> </p> tags
foreach ($matches as &$match) {
    $match = str_replace('href="', 'href="http://www.theurl.com', $match); 
	//This is used to make sure links work.
}
// output html, styles, and more.
echo '<head>';
echo '<meta http-equiv="content-type" content="text/html; charset=utf-8" />'; // make sure its able to be read correctlly
echo '</head>';
echo '<style type="text/css"></style>'; //add styles here
echo '<body>';
echo $matches[1]; // change [1] to [2] If you want to grab data between the second <p></p> tags  
echo '</body>';
?>