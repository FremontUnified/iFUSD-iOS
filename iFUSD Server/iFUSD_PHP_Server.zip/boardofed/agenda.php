<!DOCTYPE HTML>
<html> 
   <head> 
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="width=640,minimum-scale=0.5" />


   <title>Fremont Unified - Sumukh Sridhara</title> 

<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.css" />

<script src="http://code.jquery.com/jquery-1.5.2.min.js"></script>


<script src="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.js"></script>
<script type="text/javascript">

/**
 * 
 * NoClickDelay
 * http://cubiq.org/
 * 
 */
function NoClickDelay(el) {
	this.element = el;
	if( window.Touch ) this.element.addEventListener('touchstart', this, false);
}

NoClickDelay.prototype = {
	handleEvent: function(e) {
		switch(e.type) {
			case 'touchstart': this.onTouchStart(e); break;
			case 'touchmove': this.onTouchMove(e); break;
			case 'touchend': this.onTouchEnd(e); break;
		}
	},
	
	onTouchStart: function(e) {
		e.preventDefault();
		this.moved = false;
		
		this.element.addEventListener('touchmove', this, false);
		this.element.addEventListener('touchend', this, false);
	},
	
	onTouchMove: function(e) {
		this.moved = true;
	},
	
	onTouchEnd: function(e) {
		this.element.removeEventListener('touchmove', this, false);
		this.element.removeEventListener('touchend', this, false);

		if( !this.moved ) {
			var theTarget = document.elementFromPoint(e.changedTouches[0].clientX, e.changedTouches[0].clientY);
			if(theTarget.nodeType == 3) theTarget = theTarget.parentNode;

			var theEvent = document.createEvent('MouseEvents');
			theEvent.initEvent('click', true, true);
			theTarget.dispatchEvent(theEvent);
		}
	}
};

function loaded() {
}

window.addEventListener('load', function(){ setTimeout(function(){ loaded(); }, 100) }, true);
	new NoClickDelay(page);

</script>

</head> 

<body>
<body>

<div data-role="page" id="page" data-back-btn-theme="e" > 
 
	<div data-role="header"  data-theme="b"  > 
				<a href='index.php' class='ui-btn-left ui-btn-back' data-direction="reverse" rel="external"data-theme="e" data-icon='arrow-l'>Back</a>	<h1>Agendas and Minutes</h1> 
	
	</div><!-- /header --> 
 <div align=center>
<?php
$url = $_GET['url'];
$add = $_GET['add'];
echo $add;
$ch = curl_init ($url); //URL to Scrape
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$page = curl_exec($ch);

preg_match('#<div class="SWContentBODY" style="position: relative;"[^>]*>(.+?)<div class="ui-widget-footer">#is', $page, $matches, $links); // grabs anything between <p> </p> tags
foreach ($matches as &$match) {
    $match = str_replace('href="/', 'href="http://www.fmtusd.org/', $match); 
	//This is used to make sure links work.
}
// output html, styles, and more.
echo $matches[1]; // change [1] to [2] If you want to grab data between the second <p></p> tags  
?>

</div>



</div>

</body>
</html>