<? include('header.php'); ?>
<body>

<div id="page" data-role="page" >
 <!--
	<div data-role="header"  data-theme="b"> 
				<h1>Fremont Unified </h1> 
	
	</div><!-- /header --> 
 
	<div data-role="content" data-theme="b">	
	 <ul data-role="listview" class=" ui-listview" data-theme="b">
						
						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a rel="external" href="page.php?url=http://www.fremont.k12.ca.us/domain/16&title=Meetings" class="ui-link-inherit"><h2 class="ui-li-heading">Board Meetings</h2><p class="ui-li-desc">Dates and Times of Meetings</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>
						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a rel="external" href="agenda.php?url=http://www.fremont.k12.ca.us/domain/15" class="ui-link-inherit"> <h2 class="ui-li-heading">Agendas and Minutes</h2><p class="ui-li-desc">Read Agendas from the Archives!</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>
						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a rel="external" href="page.php?url=http://www.fremont.k12.ca.us/domain/14&title=Board Members" class="ui-link-inherit"><h2 class="ui-li-heading">Board Members</h2><p class="ui-li-desc">Contact Board Members</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>

						<li class="ui-btn-icon-right"><div class="ui-btn-text"><a rel="external" href="page.php?url=www.fremont.k12.ca.us/domain/19&title=Board Policies" class="ui-link-inherit"><h2 class="ui-li-heading">Board Policies</h2><p class="ui-li-desc">District Policies and Regulations</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>
												<li class="ui-btn-icon-right"><div class="ui-btn-text"><a rel="external" href="scrape.php?url=http://www.fremont.k12.ca.us/Page/13334" class="ui-link-inherit"><h2 class="ui-li-heading">SURFBoardE</h2><p class="ui-li-desc">Students liaisons to the Board of Ed</p><span class="ui-icon ui-icon-arrow-r"></span></a></div></li>






		</ul></div><!-- /content --> 

<? include('footer.php'); ?>
