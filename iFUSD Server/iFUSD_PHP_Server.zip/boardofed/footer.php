	<div data-role="footer" data-theme="b" align=center data-position="static">	
	     <div align="center">iFUSD</div> 

</div><!-- /footer --> 





</div>

</body>
</html>