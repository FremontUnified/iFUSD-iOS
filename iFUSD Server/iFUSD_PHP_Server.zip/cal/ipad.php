

<html>  
   <head>  
   <meta charset="utf-8">  

   <title>FUSD</title>   
  
<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.css" />
<script src="http://code.jquery.com/jquery-1.5.2.min.js"></script>
<script src="http://code.jquery.com/mobile/1.0a4.1/jquery.mobile-1.0a4.1.min.js"></script>
<script type="text/javascript">

/**
 * 
 * NoClickDelay
 * http://cubiq.org/
 * 
 */
function NoClickDelay(el) {
	this.element = el;
	if( window.Touch ) this.element.addEventListener('touchstart', this, false);
}

NoClickDelay.prototype = {
	handleEvent: function(e) {
		switch(e.type) {
			case 'touchstart': this.onTouchStart(e); break;
			case 'touchmove': this.onTouchMove(e); break;
			case 'touchend': this.onTouchEnd(e); break;
		}
	},
	
	onTouchStart: function(e) {
		e.preventDefault();
		this.moved = false;
		
		this.element.addEventListener('touchmove', this, false);
		this.element.addEventListener('touchend', this, false);
	},
	
	onTouchMove: function(e) {
		this.moved = true;
	},
	
	onTouchEnd: function(e) {
		this.element.removeEventListener('touchmove', this, false);
		this.element.removeEventListener('touchend', this, false);

		if( !this.moved ) {
			var theTarget = document.elementFromPoint(e.changedTouches[0].clientX, e.changedTouches[0].clientY);
			if(theTarget.nodeType == 3) theTarget = theTarget.parentNode;

			var theEvent = document.createEvent('MouseEvents');
			theEvent.initEvent('click', true, true);
			theTarget.dispatchEvent(theEvent);
		}
	}
};

function loaded() {
}

window.addEventListener('load', function(){ setTimeout(function(){ loaded(); }, 100) }, true);
	new NoClickDelay(page);

</script>

</head>  

<body>

<div id="page" data-role="page" >

<a href="webcal://www.fremont.k12.ca.us//site/UserControls/Calendar/EventExport.aspx?ModuleInstanceID=3825&StartDate=06/15/2011&EndDate=9/25/2016" alt="iFUSD Calendar" data-role="button" data-inline="false" data-theme="b">Add to Device Calendar</a>

 <iframe src="https://www.google.com/calendar/embed?title=Fremont%20Unified&amp;showNav=0&amp;showPrint=0&amp;mode=AGENDA&amp;height=600&amp;wkst=1&amp;bgcolor=%233399ff&amp;src=hj63g6omjog53ei367aefktuos7fv0th%40import.calendar.google.com&amp;color=%232F6309&amp;showCalendars=0&amp;showDate=0&amp;ctz=America%2FLos_Angeles" style=" border-width:0 " width=100% height=900px frameborder="0" scrolling="yes"></iframe>
	
	
	
	<?
// this code to use to run any file only once in spicify time
/*
$lastRunLog = 'lastrun.log';
if (file_exists($lastRunLog)) {
$lastRun = file_get_contents($lastRunLog);
if (time() - $lastRun >= 86400) {
//its been more than a day so run our external file
/// here you put the link for your file or the php code
echo "We've just updated the iFUSD Calendar to the most recent version!";
$url = "http://www.fremont.k12.ca.us//site/handlers/icalfeed.ashx?MIID=3825";

ob_start();
readfile($url);
$file = ob_get_contents();
ob_end_clean();

$fp = fopen('ifusdcalupdater.ics', 'wb');
fwrite($fp, $file);
fclose($fp);

//update lastrun.log with current time
file_put_contents($lastRunLog, time());
}
}
*/
?>
 	
 	<div data-role="footer" data-theme="b">	

</div><!-- /footer --> 



</div>

</body>